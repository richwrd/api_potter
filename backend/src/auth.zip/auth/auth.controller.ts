import { Body, Controller, Post, HttpCode, HttpStatus, UseGuards, Get, Request, HttpException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateUsuarioDto } from './usuarios/dto/create-usuario.dto';
import { Public } from './constants';
import { AuthGuard } from './auth.guard';


@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @HttpCode(HttpStatus.OK)
  @Post('register')
  async signUp(@Body() createUsuarioDto: CreateUsuarioDto): Promise<any> {
    try {
      return await this.authService.signUp(createUsuarioDto);
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @HttpCode(HttpStatus.OK)
  @Post('login')
  async signIn(@Body() signInDto: { username: string; pass: string }): Promise<any> {
    try {
      return await this.authService.signIn(signInDto.username, signInDto.pass);
    } catch (error) {
      throw new HttpException('Credenciais inválidas', HttpStatus.UNAUTHORIZED);
    }
  }

  @UseGuards(AuthGuard)
  @Get('profile')
  getProfile(@Request() req) {
    return req.user;
  }
}
