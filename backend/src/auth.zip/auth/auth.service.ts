import { Injectable, NotFoundException, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

import { CreateUsuarioDto } from './usuarios/dto/create-usuario.dto';
import { UsuariosService } from './usuarios/usuarios.service';

@Injectable()
export class AuthService {

  constructor(
    private usersService: UsuariosService,
    private jwtService: JwtService
  ) { }
  
  async signIn(username: string, pass: string): Promise<any> {
    try {
      const user = await this.usersService.findOneByUsername(username);
      if (user?.senha !== pass) {
        throw new UnauthorizedException();
      }
      const { senha, ...result } = user;

      const payload = { username: user.senha };
      return {
        access_token: await this.jwtService.signAsync(payload),
      };
      
    } catch (error) {
      console.error('Erro ao buscar usuário:', error);
      throw new UnauthorizedException('Credenciais inválidas');
    }
  }

  async signUp(createUsuarioDto: CreateUsuarioDto): Promise<any> {
    try {
      // Verifique se o email já existe
      const existingEmail = await this.usersService.findOneByEmail(createUsuarioDto.email);
      if (existingEmail) {
        throw new BadRequestException('Usuário já existe (Email)');
      }   
      
      // Verifique se o uusername já existe
      const existingUsername = await this.usersService.findOneByUsername(createUsuarioDto.username);
      if (existingUsername) {
        throw new BadRequestException('Usuário já existe (Username)');
      }

      // Crie um novo usuário
      const userCreated = await this.usersService.create(createUsuarioDto);
      const { senha, ...userData } = userCreated;

      return userData;
    } catch (error) {
      console.error('Erro ao criar usuário:', error);
      throw new BadRequestException('Erro ao criar usuário');
    }
  }
}
