import { IsString, IsEmail, MinLength, IsOptional, IsEnum } from 'class-validator';

import { TipoUsuario } from '../enums/tipo-usuario.enum';

export class CreateUsuarioDto {
  @IsString()
  id: string;

  @IsString()
  @MinLength(6)
  username: string;

  @IsEmail()
  email: string;

  @IsString()
  @MinLength(6)
  senha: string;

  @IsString()
  nome: string;

  @IsOptional()
  @IsString()
  imagem: string;

  @IsEnum(TipoUsuario)
  tipo: TipoUsuario;
}
