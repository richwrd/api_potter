export enum TipoUsuario {
  ADMIN = 'admin',
  USER = 'user',
  GUEST = 'guest',
}
